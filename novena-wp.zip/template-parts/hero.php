<?php
$hero_title = get_theme_mod('novena_hero_title', 'We Provide All Health Care Solution');
$hero_subtitle = get_theme_mod('novena_hero_subtitle', 'Protect Your Health And Take Care To Of Your Health');
$hero_button_text = get_theme_mod('novena_hero_button_text', 'Read More');
$hero_button_url = get_theme_mod('novena_hero_button_url', '#');
$hero_image = get_theme_mod('novena_hero_image', get_template_directory_uri() . '/assets/images/hero-img.png');
?>

<section class="hero-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1><?php echo esc_html($hero_title); ?></h1>
                <p><?php echo esc_html($hero_subtitle); ?></p>
                <a href="<?php echo esc_url($hero_button_url); ?>" class="btn btn-main">
                    <?php echo esc_html($hero_button_text); ?>
                </a>
            </div>
            <div class="col-lg-6">
                <img src="<?php echo esc_url($hero_image); ?>" alt="Hero Image">
            </div>
        </div>
    </div>
</section>