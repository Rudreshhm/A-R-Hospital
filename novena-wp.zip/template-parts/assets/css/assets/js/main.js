jQuery(document).ready(function($) {
    // Mobile menu toggle
    $('.navbar-toggler').on('click', function() {
        $(this).toggleClass('active');
        $('#navbarNav').toggleClass('show');
    });
    
    // Smooth scrolling for anchor links
    $('a[href*="#"]').on('click', function(e) {
        e.preventDefault();
        
        $('html, body').animate(
            {
                scrollTop: $($(this).attr('href')).offset().top,
            },
            500,
            'linear'
        );
    });
    
    // Sticky header on scroll
    $(window).on('scroll', function() {
        if ($(this).scrollTop() > 100) {
            $('.header-top').addClass('sticky');
        } else {
            $('.header-top').removeClass('sticky');
        }
    });
    
    // Testimonials slider
    if ($('.testimonials-slider').length) {
        $('.testimonials-slider').slick({
            dots: true,
            infinite: true,
            speed: 300,
            slidesToShow: 1,
            adaptiveHeight: true,
            autoplay: true,
            autoplaySpeed: 5000
        });
    }
});